const editorMainElement = document.querySelector('#editor-main')
if (editorMainElement) {
  var quillMain = new Quill('#editor-main', {theme: 'snow'});
}

const editorSideElement = document.querySelector('#editor-side')
if (editorSideElement) {
  var quillSide = new Quill('#editor-side', {theme: 'snow'});
}


function previewProductImage(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function (e) {
      $('#productImage').attr('src', e.target.result);
    };

    reader.readAsDataURL(input.files[0]);
  }
}

function previewCompanyImage(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function (e) {
      $('#companyImage').attr('src', e.target.result);
    };

    reader.readAsDataURL(input.files[0]);
  }
}


const addProductBulletPoint = document.querySelector("#addProductBulletPoint")
if (addProductBulletPoint) {
  // If product bullet point
  addProductBulletPoint.addEventListener("click", function(event) {
    event.preventDefault()
  
    const productBulletPoint = document.querySelector("#productBulletPoint")
    
    const intputGroup = document.createElement("div")
    intputGroup.classList.add("input-group", "mb-3")
    
    const inputGroupPrepend = document.createElement("div")
    inputGroupPrepend.classList.add("input-group-prepend")
    
    const button = document.createElement("button")
    button.id = "removeBulletPoint"
    button.classList.add("btn", "btn-outline-secondary")
  
    const span = document.createElement("span")
    span.setAttribute("aria-hidden", true)
    span.innerHTML = "&times;"
  
    button.append(span)
    
    const input = document.createElement("input")
    input.classList.add("form-control")
    input.setAttribute("placeholder", "Enter bulletpoint text")
    input.setAttribute("name", "product-bulletpoints")
    
    inputGroupPrepend.append(button)
    intputGroup.append(inputGroupPrepend)
    intputGroup.append(input)
    
    productBulletPoint.append(intputGroup)
  
    // We need to remove the created element 
    button.addEventListener('click', function(event) {
      intputGroup.remove()
    })
  })

  // Even though this is same event listenr this won't work agains the dynamically
  const removeProductBulletPoints = document.querySelectorAll("#removeProductBulletPoint")

  Array.from(removeProductBulletPoints).forEach(link => {
    link.addEventListener('click', function(event) {
      link.parentElement.parentElement.remove()
    });
  });

  const removeProductBulletPointDefault = document.querySelector("#removeProductBulletPointDefault")
  removeProductBulletPointDefault.addEventListener('click', function(event) {
    removeProductBulletPointDefault.parentElement.parentElement.childNodes[3].value = ""
  })
}


const addCompanyBulletPoint = document.querySelector("#addCompanyBulletPoint")
if (addCompanyBulletPoint) {
  // If company bullet point
  addCompanyBulletPoint.addEventListener("click", function(event) {
    event.preventDefault()
    const companyBulletPoint = document.querySelector("#companyBulletPoint")
    
    const intputGroup = document.createElement("div")
    intputGroup.classList.add("input-group", "mb-3")
    
    const inputGroupPrepend = document.createElement("div")
    inputGroupPrepend.classList.add("input-group-prepend")
    
    const button = document.createElement("button")
    button.id = "removeBulletPoint"
    button.classList.add("btn", "btn-outline-secondary")
  
    const span = document.createElement("span")
    span.setAttribute("aria-hidden", true)
    span.innerHTML = "&times;"
  
    button.append(span)
    
    const input = document.createElement("input")
    input.classList.add("form-control")
    input.setAttribute("placeholder", "Enter bulletpoint text")
    
    inputGroupPrepend.append(button)
    intputGroup.append(inputGroupPrepend)
    intputGroup.append(input)
    
    companyBulletPoint.append(intputGroup)
  
    // We need to remove the created element 
    button.addEventListener('click', function(event) {
      intputGroup.remove()
    })
  })

  // Even though this is same event listenr this won't work agains the dynamically
  const removeCompanyBulletPoints = document.querySelectorAll("#removeCompanyBulletPoint")

  Array.from(removeCompanyBulletPoints).forEach(link => {
    link.addEventListener('click', function(event) {
      link.parentElement.parentElement.remove()
    });
  });

  const removeCompanyBulletPointDefault = document.querySelector("#removeCompanyBulletPointDefault")
  removeCompanyBulletPointDefault.addEventListener('click', function(event) {
    removeCompanyBulletPointDefault.parentElement.parentElement.childNodes[3].value = ""
  })
}



const previewButton = document.querySelector("#previewButton")
const designForm = document.querySelector("#designForm")

previewButton.addEventListener("click", function(event) {
  const productContent = document.querySelector("#productContent")
  if (productContent) {
    // When form sumit please update the hidden content
    // productContent.value = quillMain.root.innerHTML
    productContent.value = quillMain.getText()
  }

  const companyContent = document.querySelector("#companyContent")
  if (companyContent) {
    // When form sumit please update the hidden content
    companyContent.value = quillSide.getText()
  }
  
  designForm.submit()
})
